
angular.module('starter.services', ['firebase'])

.factory('Items', ['$firebaseArray', '$firebaseAuth', function ($firebaseArray, $firebaseAuth) {
  return {
    getUserTodos: function(){
      //your firebase url
      var ref = firebase.database().ref();
      try{
        ref = firebase.database().ref("/users/"+ $firebaseAuth().$getAuth().uid);
      }catch(err){
        console.log(err.message);
      }
      return $firebaseArray(ref);
    }
  }
}])

// let's create a re-usable factory that generates the $firebaseAuth instance
.factory("AuthFB", ["$firebaseAuth",
  function($firebaseAuth) {
   return $firebaseAuth();
  }
])



.factory('Auth', ['$firebaseArray','$firebaseAuth', function ($window, $firebaseArray, $firebaseAuth) { //http://stackoverflow.com/questions/30916966/how-to-skip-login-page-if-user-is-already-logged-in-ionic-framework
   if (window.localStorage['session']) {
      var _user = JSON.parse(window.localStorage['session']);
   }
   var setUser = function (session) {
      _user = session;
      window.localStorage['session'] = JSON.stringify(_user);
   }

   return {
      setUser: setUser,
      isLoggedIn: function () {
        console.log("welcome "+ _user);
        return _user ? true : false;
        //return _user ? false : true;
      },
      getUser: function () {
         return _user;
      },
      logout: function () {
        console.log("loged out--");
         window.localStorage.removeItem("session");
         window.localStorage.removeItem("list_dependents");
         _user = null;
         //$window.location.reload(true);
      }
   }
}]);
