var firebaseURL = "https://todoapp-59cde.firebaseio.com/users/"; 

var config = {
  apiKey: "AIzaSyD4al9qrvsUhvKG99OC55_-dWOrj-H0jco",
  authDomain: "todoapp-59cde.firebaseapp.com",
  databaseURL: "https://todoapp-59cde.firebaseio.com",
  storageBucket: "todoapp-59cde.appspot.com",
};
firebase.initializeApp(config);


angular.module('starter.controllers', ['firebase', 'ionicRipple', 'ion-floating-menu'])

.controller('ListsCtrl', function($scope, $ionicListDelegate, Items, $ionicPopup, Auth, AuthFB, $firebaseAuth, $ionicViewService, $location) { //, $firebase, $firebaseArray

  if(!Auth.isLoggedIn()) { 
    alert("you are not logged in");
      $ionicViewService.nextViewOptions({ //clear the navigation stack and then redirect to the sign in view, clear stack because of android back button
          disableAnimate: true,
          disableBack: true
      });
      $location.path("/app/login");
  }
    
  $scope.items = "";  

  $scope.$on('$ionicView.enter', function(e) {
    console.log("view entered-------------");
    if($firebaseAuth().$getAuth()==null) { 
      console.log("user seems to be not logged in");
        $ionicViewService.nextViewOptions({ 
            disableAnimate: true,
            disableBack: true
        });
        $location.path("/app/login");
    }else{
      $scope.items = Items.getUserTodos();
    }
  });

  
  $scope.inputs = {};
  $scope.create = function(){
        var myPopup = $ionicPopup.show({
    template: '<input class="todoInput" ng-model="inputs.text" placeholder="watch star wars...">',
    title: 'New Todo',
    cssClass: "todo-popup",
    scope: $scope,
    buttons: [
      { text: 'Cancel' },
      {
        text: '<b>Save</b>',
        type: 'button-royal',
        onTap: function(e) {
          if (!$scope.inputs.text) {
            //don't allow the user to save unless he enters text
            e.preventDefault();
          } else {
            //return $scope.input.text;
             $scope.items.$add({ //$add is by angularfire, an add function creates a new record in firebase and adds the reocord to the synchronized array
                'name' : $scope.inputs.text,
                'created' : firebase.database.ServerValue.TIMESTAMP
              });
            $scope.inputs = {};
          }
        }
      }
    ]
  });
  }

  $scope.doneItem = function(item){
    console.log("--- - " + $firebaseAuth().$getAuth().uid); 
    var itemRef = firebase.database().ref("/users/"+ $firebaseAuth().$getAuth().uid + '/' +item.$id); //new Firebase(firebaseURL + fb.getAuth().uid + '/' + item.$id);
    itemRef.child('status').set('done');
    $ionicListDelegate.closeOptionButtons();
  };

  $scope.removeItem = function(item){

    var confirmPopup = $ionicPopup.confirm({
     title: 'Delete',
     template: 'Are you sure you want to delete this todo?',
     okText: 'OK',
     cancelText: 'CANCEL',
     okType: 'button-royal',
     cancelType: 'button-light',
     cssClass: "todo-popup"
    });

   confirmPopup.then(function(res) {
     if(res) {
      var itemRef = firebase.database().ref("/users/"+ $firebaseAuth().$getAuth().uid + '/' +item.$id);
      itemRef.remove();   
     } else {
       console.log('not deleted');
     }
   });  
    $ionicListDelegate.closeOptionButtons();
  };

  $scope.undoItem = function(item){
    var itemRef = firebase.database().ref("/users/"+ $firebaseAuth().$getAuth().uid + '/' +item.$id);      
    itemRef.update({status: 'undone'});
    $ionicListDelegate.closeOptionButtons();
  }

  $scope.updateItem = function(item){
    $scope.editName = item.name;
    var myPopup = $ionicPopup.show({
      template: '<textarea rows="4" cols="50" ng-model="$parent.editName">{{editName}}',
      title: 'Edit Todo',
      cssClass: "todo-popup",
      scope: $scope,
      buttons: [
        { text: 'Cancel' },
        {
          text: '<b>Save</b>',
          type: 'button-royal',
          onTap: function(e) {
            if (!$scope.editName) {
              //don't allow the user to save unless he enters text
              e.preventDefault();
            } else {
                var itemRef = firebase.database().ref("/users/"+ $firebaseAuth().$getAuth().uid + '/' +item.$id);
                itemRef.update({name: $scope.editName});
            }
          }
        }
      ]
    });
    $ionicListDelegate.closeOptionButtons();
  }

  $scope.data = {};//used for reorder...


  $scope.moveItem = function(item, fromIndex, toIndex) {
    //Move the item in the array
    $scope.items.splice(fromIndex, 1);
    $scope.items.splice(toIndex, 0, item);
  };

  $scope.onReorder = function (fromIndex, toIndex) {
        var moved = $scope.items.splice(fromIndex, 1);
        $scope.items.splice(toIndex, 0, moved[0]);
        console.log("to " + toIndex + " from " + fromIndex + " name " + moved[0].name);
  };

})


.controller('LoginCtrl', function($scope, $firebaseAuth, $location, Auth, AuthFB, $firebaseAuth, $ionicPopup, $ionicSideMenuDelegate, $ionicViewService, $location) {


  //deactivate drag on login and hide burger
  $ionicSideMenuDelegate.canDragContent(false);
  
  $scope.showReset = false;
  $scope.toggleReset = function(){
      $scope.showReset = !$scope.showReset;
  };

  $scope.loginUser = function(username, password){
    AuthFB.$signInWithEmailAndPassword(username, password).then(function(authData){      
      console.log("logged in as user with id " + authData.uid);
      Auth.setUser(authData.uid); //save user id in localstorage
      console.log("saved session");
      $ionicViewService.nextViewOptions({ //clear the navigation stack and then redirect to the sign in view, clear stack because of android back button
        disableBack: true
      });
      $location.path("/app/list");
    }).catch(function(error){
      if (error) {
        switch (error.code) {
          case "INVALID_PASSWORD":
            console.log("The specified user account does not exist.");
            $scope.invalidPasswordPopup();
            break;
          default:
            console.log("login with wrong password:", error);
            $scope.invalidPasswordPopup();
        }
      } 
    });
  }

  $scope.invalidPasswordPopup = function(){
   var confirmPopup = $ionicPopup.alert({
       title: 'Oh no!',
       template: 'The password is invalid or the user does not have a password.',
       okText: 'OK',  
       okType: 'button-royal',
       cssClass: "todo-alert"
     });
  }


  //new Firebase
  $scope.register = function(username, password) {
    AuthFB.$createUserWithEmailAndPassword(username, password).then(function(userData) {
      console.log("---- " + "User created with uid: " + userData.uid);
      Auth.setUser(userData.uid); //save user id in localstorage
       $ionicViewService.nextViewOptions({ //clear the navigation stack and then redirect to the sign in view, clear stack because of android back button
        disableBack: true
      });
      alert("Thank you for registering!");
      $location.path("/app/list");
    }).catch(function(error) {
      console.log("---- " + error);
      alert("Sorry: " + error);
    });
  }

  $scope.resetPassword = function(username){
    AuthFB.$sendPasswordResetEmail(username).then(function(){
      $scope.resetPasswordSuccessPopup(username);
    }).catch(function(error) {
      if (error) {
        switch (error.code) {
          case "auth/user-not-found":
            console.log("The specified user account does not exist.");
            $scope.userNotFoundPopup();
            break;
          default:
            console.log("Error resetting password:", error);
            $scope.resetPasswordErrorPopup();
        }
      } else {
        console.log("Password reset email sent successfully!");
      }
    });
  }

  $scope.userNotFoundPopup = function(){
   var confirmPopup = $ionicPopup.alert({
       title: 'Hey no such user!',
       template: 'The specified user account does not exist.',
       okText: 'OK',  
       okType: 'button-royal',
       cssClass: "todo-alert"
     });
  }

  $scope.resetPasswordErrorPopup = function(){
   var confirmPopup = $ionicPopup.alert({
       title: 'Oops!',
       template: 'There has been an error with resetting your password. Please try again.',
       okText: 'OK',  
       okType: 'button-royal',
       cssClass: "todo-alert"
     });
  }

  $scope.resetPasswordSuccessPopup = function(){
   var confirmPopup = $ionicPopup.alert({
       title: 'Hey!',
       template: 'An email has been sent to reset your password. Check your email!',
       okText: 'OK',  
       okType: 'button-royal',
       cssClass: "todo-alert"
     });
  }

  $scope.oldPassword = "";
  $scope.newPassword = "";
  $scope.updatePassword = function(setNewPassword, confirmNewPassword){
    AuthFB.$updatePassword(setNewPassword).then(function(){
       $scope.updatePopup();
    }).catch(function(error) {
      if (error) {
        switch (error.code) {
          case "INVALID_PASSWORD":
            console.log("The specified user account password is incorrect.");
            $scope.updatePopupErrorOld();
            break;
          case "INVALID_USER":
            console.log("The specified user account does not exist.");
            $scope.updatePopupNoUser();
            break;
          default:
            console.log("Error changing password:", error);
        }
      } else {
        console.log("User password changed successfully!");
        $scope.updatePopup();
      }
    });
  }

  $scope.updatePopup = function(){
   var confirmPopup = $ionicPopup.alert({
       title: 'Yay!',
       template: 'User password changed successfully!',
       okText: 'OK',  
       okType: 'button-royal',
       cssClass: "todo-alert"
     });
  }

  $scope.updatePopupError = function(){
   var confirmPopup = $ionicPopup.alert({
       title: 'Ooppps',
       template: 'Something went wrong, try again!',
       okText: 'OK',  
       okType: 'button-royal',
       cssClass: "todo-alert"
     });
  }

  $scope.updatePopupErrorOld = function(){
   var confirmPopup = $ionicPopup.alert({
       title: 'Ooppps',
       template: 'Wrong old password!',
       okText: 'OK',  
       okType: 'button-royal',
       cssClass: "todo-alert"
     });
  }

  $scope.updatePopupNoUser = function(){
   var confirmPopup = $ionicPopup.alert({
       title: 'Ooppps',
       template: 'The specified user account does not exist.',
       okText: 'OK',  
       okType: 'button-royal',
       cssClass: "todo-alert"
     });
  }

  $scope.logout = function(){
      //AuthFB.$getAuth().$signOut();
      alert($firebaseAuth().$getAuth().email);
      Auth.logout();
      firebase.auth().signOut().then(function() {
        console.log("Sign-out successful");
      }, function(error) {
        alert("Sorry " + error);
      });
  }

})


.controller('DetaillistCtrl', function($scope, $stateParams) {
  $scope.item = $stateParams.listId;
});








