angular.module('starter.services', ['firebase'])


// .factory('Items', ['$firebaseArray', function ($firebaseArray) {
//   var itemsRef = new Firebase('https://laterappo.firebaseio.com/items');
//   return $firebaseArray(itemsRef);
// }])

.factory('Items2', ['$firebaseArray', function ($firebaseArray) {
  return {
    getUserTodos: function(){
      var fb = new Firebase("https://laterappo.firebaseio.com/users/");
      var fbAuth = fb.getAuth();
      console.log("service1 ------- " + fbAuth.uid);
      var itemsRef = new Firebase('https://laterappo.firebaseio.com/users/' + fbAuth.uid); 
      console.log("service ------- " + fbAuth.uid);
      return $firebaseArray(itemsRef);
    }
  }
}])


.factory('Auth', function ($window) { //http://stackoverflow.com/questions/30916966/how-to-skip-login-page-if-user-is-already-logged-in-ionic-framework
   if (window.localStorage['session']) {
      var _user = JSON.parse(window.localStorage['session']);
   }
   var setUser = function (session) {
      _user = session;
      window.localStorage['session'] = JSON.stringify(_user);
   }

   return {
      setUser: setUser,
      isLoggedIn: function () {
        console.log("welcome "+ _user);
        return _user ? true : false;
        //return _user ? false : true;
         //return false;
      },
      getUser: function () {
         return _user;
      },
      logout: function () {
        console.log("loged out--");
         window.localStorage.removeItem("session");
         window.localStorage.removeItem("list_dependents");
         _user = null;
         //$window.location.reload(true);
      }
   }
});
