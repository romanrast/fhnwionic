# Change Log
All notable changes to this project will be documented in this file.
This project adheres to [Semantic Versioning](http://semver.org/).

## [1.0.8] - 2016-03-21
### Fixed
- Add animation deactivation.

## [1.0.7] - 2016-03-16
### Fixed
- Fix ripple element creation.

## [1.0.5] - 2016-03-16
### Fixed
- Stop event propagation.
