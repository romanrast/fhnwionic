angular.module('starter.controllers', ['firebase', 'ionicRipple', 'ion-floating-menu'])

.controller('AppCtrl', function($scope, $ionicModal, $timeout, Auth) {

  // With the new view caching in Ionic, Controllers are only called
  // when they are recreated or on app start, instead of every page change.
  // To listen for when this page is active (for example, to refresh data),
  // listen for the $ionicView.enter event:
  //$scope.$on('$ionicView.enter', function(e) {
  //});

  // Form data for the login modal
  $scope.loginData = {};

  // Create the login modal that we will use later
  // $ionicModal.fromTemplateUrl('templates/modallogin.html', {
  //   scope: $scope
  // }).then(function(modal) {
  //   $scope.modal = modal;
  // });

  // Triggered in the login modal to close it
  $scope.closeLogin = function() {
    $scope.modal.hide();
  };

  // Open the login modal
  $scope.login = function() {
    $scope.modal.show();
  };

  // Perform the login action when the user submits the login form
  $scope.doLogin = function() {
    console.log('Doing login', $scope.loginData);

    // Simulate a login delay. Remove this and replace with your login
    // code if using a login system
    $timeout(function() {
      $scope.closeLogin();
    }, 1000);
  };

  $scope.logout = function(){
    Auth.logout();
  }

})

.controller('ListsCtrl', function($scope, $ionicListDelegate, Items2, $ionicPopup) { //, $firebase, $firebaseArray

$scope.items = "";  
var fb = new Firebase("https://laterappo.firebaseio.com/users/");

$scope.$on('$ionicView.enter', function(e) {
  console.log("view entered-------------");
  $scope.items = Items2.getUserTodos();
});

console.log(fb.getAuth().uid);
$scope.inputs = {};
  $scope.create = function(){
        var myPopup = $ionicPopup.show({
    template: '<input class="todoInput" ng-model="inputs.text" placeholder="watch star wars...">',
    title: 'New Todo',
    cssClass: "todo-popup",
    scope: $scope,
    buttons: [
      { text: 'Cancel' },
      {
        text: '<b>Save</b>',
        type: 'button-royal',
        onTap: function(e) {
          if (!$scope.inputs.text) {
            //don't allow the user to save unless he enters text
            e.preventDefault();
          } else {
            //return $scope.input.text;
             $scope.items.$add({ //$add is by angularfire, an add function creates a new record in firebase and adds the reocord to the synchronized array
                'name' : $scope.inputs.text,
                'created' : Firebase.ServerValue.TIMESTAMP
              });
            $scope.inputs = {};
          }
        }
      }
    ]
  });
  }

  $scope.addItem = function(){
    $scope.input = {};
    var myPopup = $ionicPopup.show({
      template: '<input class="todoInput" ng-model="input.text" placeholder="watch star wars...">',
      title: 'New Todo',
      cssClass: "todo-popup",
      scope: $scope,
      buttons: [
        { text: 'Cancel' },
        {
          text: '<b>Save</b>',
          type: 'button-royal',
          onTap: function(e) {
            if (!$scope.input.text) {
              //don't allow the user to save unless he enters text
              e.preventDefault();
            } else {
              //return $scope.input.text;
               $scope.items.$add({ //$add is by angularfire, an add function creates a new record in firebase and adds the reocord to the synchronized array
                  'name' : $scope.input.text
                });
            }
          }
        }
      ]
    });
  };

  $scope.doneItem = function(item){
    //var itemRef = new Firebase('https://laterappo.firebaseio.com/items/' + item.$id);
    var itemRef = new Firebase('https://laterappo.firebaseio.com/users/'+ fb.getAuth().uid + '/' + item.$id);
    // $scope.item = item;
    // $scope.item['status'] = 'done';
    itemRef.child('status').set('done');
    $ionicListDelegate.closeOptionButtons();
  };

  $scope.removeItem = function(item){

    var confirmPopup = $ionicPopup.confirm({
     title: 'Delete',
     template: 'Are you sure you want to delete this todo?',
     okText: 'OK',
     cancelText: 'CANCEL',
     okType: 'button-royal',
     cancelType: 'button-light',
     cssClass: "todo-popup"
    });

   confirmPopup.then(function(res) {
     if(res) {
      //var itemRef = new Firebase('https://laterappo.firebaseio.com/items/' + item.$id);
      var itemRef = new Firebase('https://laterappo.firebaseio.com/users/'+ fb.getAuth().uid + '/' + item.$id);
      itemRef.remove();   
     } else {
       console.log('not deleted');
     }
   });  
    $ionicListDelegate.closeOptionButtons();
  };

  $scope.undoItem = function(item){
    //var itemRef = new Firebase('https://laterappo.firebaseio.com/items/' + item.$id);
    var itemRef = new Firebase('https://laterappo.firebaseio.com/users/'+ fb.getAuth().uid + '/' + item.$id);
    itemRef.update({status: 'undone'});
    $ionicListDelegate.closeOptionButtons();
  }

  $scope.updateItem = function(item){
  $scope.editName = item.name;
  var myPopup = $ionicPopup.show({
    template: '<textarea rows="4" cols="50" ng-model="$parent.editName">{{editName}}',
    title: 'Edit Todo',
    cssClass: "todo-popup",
    scope: $scope,
    buttons: [
      { text: 'Cancel' },
      {
        text: '<b>Save</b>',
        type: 'button-royal',
        onTap: function(e) {
          if (!$scope.editName) {
            //don't allow the user to save unless he enters text
            e.preventDefault();
          } else {
            //return $scope.input.text;
              //var itemRef = new Firebase('https://laterappo.firebaseio.com/items/' + item.$id);
              var itemRef = new Firebase('https://laterappo.firebaseio.com/users/'+ fb.getAuth().uid + '/' + item.$id);
              itemRef.update({name: $scope.editName});
          }
        }
      }
    ]
  });
  $ionicListDelegate.closeOptionButtons();

}

$scope.data = {};//used for reorder...


$scope.moveItem = function(item, fromIndex, toIndex) {
    //Move the item in the array
    $scope.items.splice(fromIndex, 1);
    $scope.items.splice(toIndex, 0, item);
  };

 $scope.onReorder = function (fromIndex, toIndex) {
        var moved = $scope.items.splice(fromIndex, 1);
        $scope.items.splice(toIndex, 0, moved[0]);
    };

})


.controller('LoginCtrl', function($scope, $firebaseAuth, $location, Auth, $ionicPopup, $ionicSideMenuDelegate) {

  //deactivate drag on login and hide burger
  $ionicSideMenuDelegate.canDragContent(false);

  var fb = new Firebase("https://laterappo.firebaseio.com/users/");

  $scope.showReset = false;
  $scope.toggleReset = function(){
      $scope.showReset = !$scope.showReset;
    };


  $scope.loginUser = function(username, password){
    var fbAuth = $firebaseAuth(fb);
    fbAuth.$authWithPassword({
      email: username,
      password: password
    }).then(function(authData){
      //Auth.setUser("123456");
      Auth.setUser(authData.uid);
      console.log("saved session");
        $location.path("/app/list");
    }).catch(function(error){
      alert("error: " + error);
    });
  }

  $scope.register = function(username, password){
    //alert("dd");
    var fbAuth = $firebaseAuth(fb);
    fbAuth.$createUser({email: username, password: password}).then(function(){
        return fbAuth.$authWithPassword({
          email: username,
          password: password
        });
    }).then(function(authData){
      $location.path("/app/list");
    }).catch(function(error){
      alert("error: " + error);
    });
  }

$scope.resetPassword = function(username){
  fb.resetPassword({
    email: username
  }, function(error) {
    if (error) {
      switch (error.code) {
        case "INVALID_USER":
          console.log("The specified user account does not exist.");
          break;
        default:
          console.log("Error resetting password:", error);
      }
    } else {
      console.log("Password reset email sent successfully!");
    }
  });
}

$scope.oldPassword = "";
$scope.newPassword = "";
$scope.updatePassword = function(username, oldPassword, newPassword){
  fb.changePassword({
    email: username,
    oldPassword: oldPassword,
    newPassword: newPassword
  }, function(error) {
    if (error) {
      switch (error.code) {
        case "INVALID_PASSWORD":
          console.log("The specified user account password is incorrect.");
          $scope.updatePopupErrorOld();
          break;
        case "INVALID_USER":
          console.log("The specified user account does not exist.");
          $scope.updatePopupNoUser();
          break;
        default:
          console.log("Error changing password:", error);
      }
    } else {
      console.log("User password changed successfully!");
      $scope.updatePopup();
    }
  });
}

$scope.updatePopup = function(){
 var confirmPopup = $ionicPopup.alert({
     title: 'Yay!',
     template: 'User password changed successfully!',
     okText: 'OK',  
     okType: 'button-royal',
     cssClass: "todo-alert"
   });
}

$scope.updatePopupError = function(){
 var confirmPopup = $ionicPopup.alert({
     title: 'Ooppps',
     template: 'Something went wrong, try again!',
     okText: 'OK',  
     okType: 'button-royal',
     cssClass: "todo-alert"
   });
}

$scope.updatePopupErrorOld = function(){
 var confirmPopup = $ionicPopup.alert({
     title: 'Ooppps',
     template: 'Wrong old password!',
     okText: 'OK',  
     okType: 'button-royal',
     cssClass: "todo-alert"
   });
}

$scope.updatePopupNoUser = function(){
 var confirmPopup = $ionicPopup.alert({
     title: 'Ooppps',
     template: 'The specified user account does not exist.',
     okText: 'OK',  
     okType: 'button-royal',
     cssClass: "todo-alert"
   });
}

$scope.logout = function(){
    Auth.logout();
}


})




.controller('DetaillistCtrl', function($scope, $stateParams) {
  $scope.item = $stateParams.listId;
});








