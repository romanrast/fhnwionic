angular.module('starter.services', [])

.factory('Chats', function() {
  // Might use a resource here that returns a JSON array

  // Some fake testing data
  var chats = [{
    id: 0,
    name: 'Chewbacca',
    lastText: 'Muuuuuaaaaa',
    face: 'img/Chewbacca1.png'
  }, {
    id: 1,
    name: 'Han Solo',
    lastText: 'Hey, it\'s me! Greedo shot first!',
    face: 'img/hansolo.png'
  }, {
    id: 2,
    name: 'Princess Leia',
    lastText: 'I love you',
    face: 'img/LeiaOrgana.png'
  }, {
    id: 3,
    name: 'Admiral Ackbar',
    lastText: 'It\'s a trap!!',
    face: 'img/Ackbar.png'
  }, {
    id: 4,
    name: 'BB8',
    lastText: 'Wooo',
    face: 'img/BB8.png'
  }];

  return {
    all: function() {
      return chats;
    },
    remove: function(chat) {
      chats.splice(chats.indexOf(chat), 1);
    },
    get: function(chatId) {
      for (var i = 0; i < chats.length; i++) {
        if (chats[i].id === parseInt(chatId)) {
          return chats[i];
        }
      }
      return null;
    }
  };
});
