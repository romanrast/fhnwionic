angular.module('starter.controllers', ['firebase'])

.controller('AppCtrl', function($scope, $ionicModal, $timeout) {

  // With the new view caching in Ionic, Controllers are only called
  // when they are recreated or on app start, instead of every page change.
  // To listen for when this page is active (for example, to refresh data),
  // listen for the $ionicView.enter event:
  //$scope.$on('$ionicView.enter', function(e) {
  //});

  // Form data for the login modal
  $scope.loginData = {};

  // Create the login modal that we will use later
  $ionicModal.fromTemplateUrl('templates/login.html', {
    scope: $scope
  }).then(function(modal) {
    $scope.modal = modal;
  });

  // Triggered in the login modal to close it
  $scope.closeLogin = function() {
    $scope.modal.hide();
  };

  // Open the login modal
  $scope.login = function() {
    $scope.modal.show();
  };

  // Perform the login action when the user submits the login form
  $scope.doLogin = function() {
    console.log('Doing login', $scope.loginData);

    // Simulate a login delay. Remove this and replace with your login
    // code if using a login system
    $timeout(function() {
      $scope.closeLogin();
    }, 1000);
  };
})

.controller('PlaylistsCtrl', function($scope, $ionicListDelegate, Items, Items2, $ionicPopup, $firebase, $firebaseArray) {
  $scope.itemss = [
    { name: 'Reggae', id: 1 },
    { name: 'Chill', id: 2 },
    { name: 'Dubstep', id: 3 },
    { name: 'Indie', id: 4 },
    { name: 'Rap', id: 5 },
    { name: 'Cowbell', id: 6 }
  ];

  var fb = new Firebase("https://laterapp.firebaseio.com/");


  // var items = function(){
  //   alert("foo");
  //   var fbAuth = fb.getAuth();
  //   console.log(fb.getAuth());
  //   // if(fbAuth){
  //   //   var sync = $firebase(fb.child("users/" + fbAuth.uid));
  //   //   var syncObject = sync.$asObject();
  //   //   syncObject.$bindTo($scope, "items");
  //   // }
  //   var itemsRef = new Firebase('https://laterapp.firebaseio.com/users/' + fbAuth.uid);
  //   //return $firebaseArray(itemsRef);
  //   console.log("fooof "+itemsRef);
  // }

$scope.items = Items2;
console.log(fb.getAuth().uid);
$scope.inputs = {};
  $scope.create = function(){
        var myPopup = $ionicPopup.show({
    template: '<input class="todoInput" ng-model="inputs.text" placeholder="watch star wars...">',
    title: 'New Todo',
    cssClass: "todo-popup",
    scope: $scope,
    buttons: [
      { text: 'Cancel' },
      {
        text: '<b>Save</b>',
        type: 'button-royal',
        onTap: function(e) {
          if (!$scope.inputs.text) {
            //don't allow the user to save unless he enters text
            e.preventDefault();
          } else {
            //return $scope.input.text;
             $scope.items.$add({ //$add is by angularfire, an add function creates a new record in firebase and adds the reocord to the synchronized array
                'name' : $scope.inputs.text
              });
            $scope.inputs = {};
          }
        }
      }
    ]
  });
  }


//.....

// $scope.items = Items;

  $scope.addItem = function(){
    // var name = prompt('New ToDo');
    // if(name){
    //   $scope.items.$add({ //$add is by angularfire, an add function creates a new record in firebase and adds the reocord to the synchronized array
    //     'name' : name
    //   });
    // }
  $scope.input = {};
  var myPopup = $ionicPopup.show({
    template: '<input class="todoInput" ng-model="input.text" placeholder="watch star wars...">',
    title: 'New Todo',
    cssClass: "todo-popup",
    scope: $scope,
    buttons: [
      { text: 'Cancel' },
      {
        text: '<b>Save</b>',
        type: 'button-royal',
        onTap: function(e) {
          if (!$scope.input.text) {
            //don't allow the user to save unless he enters text
            e.preventDefault();
          } else {
            //return $scope.input.text;
             $scope.items.$add({ //$add is by angularfire, an add function creates a new record in firebase and adds the reocord to the synchronized array
                'name' : $scope.input.text
              });
          }
        }
      }
    ]
  });


  };

  $scope.doneItem = function(item){
    //var itemRef = new Firebase('https://laterappo.firebaseio.com/items/' + item.$id);
    var itemRef = new Firebase('https://laterappo.firebaseio.com/users/'+ fb.getAuth().uid + '/' + item.$id);
    // $scope.item = item;
    // $scope.item['status'] = 'done';
    itemRef.child('status').set('done');
    $ionicListDelegate.closeOptionButtons();
  };

  $scope.removeItem = function(item){

    var confirmPopup = $ionicPopup.confirm({
     title: 'Delete',
     template: 'Are you sure you want to delete this todo?',
     okText: 'OK',
     cancelText: 'CANCEL',
     okType: 'button-royal',
     cancelType: 'button-light',
     cssClass: "todo-popup"
   });

   confirmPopup.then(function(res) {
     if(res) {
      //var itemRef = new Firebase('https://laterappo.firebaseio.com/items/' + item.$id);
      var itemRef = new Firebase('https://laterappo.firebaseio.com/users/'+ fb.getAuth().uid + '/' + item.$id);
      itemRef.remove();   
     } else {
       console.log('not deleted');
     }
   });  
    $ionicListDelegate.closeOptionButtons();
  };

  $scope.undoItem = function(item){
    //var itemRef = new Firebase('https://laterappo.firebaseio.com/items/' + item.$id);
    var itemRef = new Firebase('https://laterappo.firebaseio.com/users/'+ fb.getAuth().uid + '/' + item.$id);
    itemRef.update({status: 'undone'});
    $ionicListDelegate.closeOptionButtons();
  }

  $scope.updateItem = function(item){
    // var newName = prompt('Edit ToDo');
    // if(newName){
    //   var itemRef = new Firebase('https://laterappo.firebaseio.com/items/' + item.$id);
    //   itemRef.update({name: newName});
    //   $ionicListDelegate.closeOptionButtons();
    // }

  //  $scope.inputUpadte = {};
  $scope.editName = item.name;
  var myPopup = $ionicPopup.show({
    template: '<textarea rows="4" cols="50" ng-model="$parent.editName">{{editName}}',
    title: 'Edit Todo',
    cssClass: "todo-popup",
    scope: $scope,
    buttons: [
      { text: 'Cancel' },
      {
        text: '<b>Save</b>',
        type: 'button-royal',
        onTap: function(e) {
          if (!$scope.editName) {
            //don't allow the user to save unless he enters text
            e.preventDefault();
          } else {
            //return $scope.input.text;
            
              //var itemRef = new Firebase('https://laterappo.firebaseio.com/items/' + item.$id);
              var itemRef = new Firebase('https://laterappo.firebaseio.com/users/'+ fb.getAuth().uid + '/' + item.$id);
              itemRef.update({name: $scope.editName});
          }
        }
      }
    ]
  });
  $ionicListDelegate.closeOptionButtons();

}

})


.controller('LogintCtrl', function($scope, $firebaseAuth, $location) {

  var fb = new Firebase("https://laterapp.firebaseio.com/");

  $scope.loginUser = function(username, password){
    var fbAuth = $firebaseAuth(fb);
    fbAuth.$authWithPassword({
      email: username,
      password: password
    }).then(function(authData){
        $location.path("/app/playlists");
    }).catch(function(error){
      alert("error: " + error);
    });
  }

  $scope.register = function(username, password){
    //alert("dd");
    var fbAuth = $firebaseAuth(fb);
    fbAuth.$createUser({email: username, password: password}).then(function(){
        return fbAuth.$authWithPassword({
          email: username,
          password: password
        });
    }).then(function(authData){
      $location.path("/app/playlists");
    }).catch(function(error){
      alert("error: " + error);
    });
  }

})


.controller('PlaylistCtrl', function($scope, $stateParams) {
});








