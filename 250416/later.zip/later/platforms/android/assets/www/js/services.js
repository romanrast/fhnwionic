angular.module('starter.services', ['firebase'])

.factory('Chats', function() {
  // Might use a resource here that returns a JSON array

  // Some fake testing data
  var chats = [{
    id: 0,
    name: 'Chewbacca',
    lastText: 'Muuuuuaaaaa',
    face: 'img/Chewbacca1.png'
  }, {
    id: 1,
    name: 'Han Solo',
    lastText: 'Hey, it\'s me! Greedo shot first!',
    face: 'img/hansolo.png'
  }, {
    id: 2,
    name: 'Princess Leia',
    lastText: 'I love you',
    face: 'img/LeiaOrgana.png'
  }, {
    id: 3,
    name: 'Admiral Ackbar',
    lastText: 'It\'s a trap!!',
    face: 'img/Ackbar.png'
  }, {
    id: 4,
    name: 'BB8',
    lastText: 'Wooo',
    face: 'img/BB8.png'
  }];


  return {
    all: function() {
      return chats;
    },
    remove: function(chat) {
      chats.splice(chats.indexOf(chat), 1);
    },
    get: function(chatId) {
      for (var i = 0; i < chats.length; i++) {
        if (chats[i].id === parseInt(chatId)) {
          return chats[i];
        }
      }
      return null;
    }
  };
})

.factory('Items', ['$firebaseArray', function ($firebaseArray) {
  var itemsRef = new Firebase('https://laterappo.firebaseio.com/items');
  return $firebaseArray(itemsRef);
}])

.factory('Items2', ['$firebaseArray', function ($firebaseArray) {
   var fb = new Firebase("https://laterapp.firebaseio.com/");
   var fbAuth = fb.getAuth();
  var itemsRef = new Firebase('https://laterappo.firebaseio.com/users/' + fbAuth.uid); 
  return $firebaseArray(itemsRef);
}])



.factory('weatherAPI', function($http) {

  return {
    getWeatherCity: function(callback) {
            // openweathermap key for user romanrast fb7d210f276e006391ca0851fdbb3e7a    
            $http.get('http://api.openweathermap.org/data/2.5/weather?q=Basel&APPID=fb7d210f276e006391ca0851fdbb3e7a').success(function(data) {
              var savedWeather = data;
                callback(savedWeather);
            });
        },

    getWeatherLoaction: function(latitude, longitude, callback) {
//      alert("gettin service location");
           // openweathermap key for user romanrast fb7d210f276e006391ca0851fdbb3e7a    
            $http.get('http://api.openweathermap.org/data/2.5/weather?lat=' + latitude + '&lon=' + longitude + '&cnt=2&mode=json&APPID=fb7d210f276e006391ca0851fdbb3e7a').success(function(data) {
              var savedWeather2 = data;
                callback(savedWeather2);
            });
        }

  };
});
