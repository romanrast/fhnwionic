angular.module('starter.controllers', [])

.controller('WeatherCtrl', function($scope, $stateParams, Chats, $ionicScrollDelegate, $ionicListDelegate, $http, weatherAPI, $state, $rootScope, $cordovaGeolocation) {

  //$scope.chat = Chats.get($stateParams.chatId);
//CHATS ------------------
  $scope.chats = Chats.all();
  $scope.remove = function(chat) {
    Chats.remove(chat);
  };

  $scope.toggleStar = function(chat){
    chat.star = !chat.star;
    $ionicListDelegate.closeOptionButtons();
  }
  $scope.doRefresh = function(){
    $scope.chats = Chats.all();
    $scope.$broadcast('scroll.refreshComplete');
  }

//for parallax effect
  $scope.onUserDetailContentScroll = function(){
    var scrollDelegate = $ionicScrollDelegate.$getByHandle('userDetailContent');
    var scrollView = scrollDelegate.getScrollView();
    $scope.$broadcast('userDetailContent.scroll', scrollView);
  }
//-------------------------

//WEATHER -----------------
  $scope.getWeatherByCity = function(){
    weatherAPI.getWeatherCity(function(results) {
      $scope.weatherCity = results;
      var tempLong = $scope.weatherCity.main.temp - 273.15;
      var tempFixed = tempLong.toFixed(0);
      $scope.tempCity = tempFixed;
      $scope.weatherDescription = $scope.weatherCity.weather[0].description;
    });
  }
 
//GEOLOCATION
  $scope.getGeoLocation  = function(){
   var posOptions = {timeout: 10000, enableHighAccuracy: false};
        $cordovaGeolocation
          .getCurrentPosition(posOptions)
          .then(function (position) {
            console.log("------ lat is: " +position.coords.latitude + ' long is: ' + position.coords.longitude)
            weatherAPI.getWeatherLoaction(position.coords.latitude, position.coords.longitude, function(results){
              $scope.weatherGeo = results;
              var tempLong = $scope.weatherGeo.main.temp - 273.15;
              var tempFixed = tempLong.toFixed(0);
              $scope.tempGeo = tempFixed;
            });
          }, function(err) {
            // error
            console.log(err)
          });
  }

  $scope.doRefreshWeatherGeo = function(){
    //update weather with geolocation
    $scope.getGeoLocation();
    $scope.$broadcast('scroll.refreshComplete');
  };

  $scope.doRefreshWeatherCity = function(){
    // update weather with known city name (basel)
    $scope.getWeatherByCity();
    $scope.$broadcast('scroll.refreshComplete');
  };


  var init = function () {
   //get weather from geolocation on view load
   $scope.getGeoLocation();
   //get weather from city
   $scope.getWeatherByCity();
  };
  init();

})

.controller('WeatherDetailCtrl', function($scope, $stateParams, Chats, $ionicScrollDelegate) { //Chats is the Factory Service we are using
  $scope.chat = Chats.get($stateParams.chatId);

//for parallax effect
  $scope.onUserDetailContentScroll = function(){
    var scrollDelegate = $ionicScrollDelegate.$getByHandle('userDetailContent');
    var scrollView = scrollDelegate.getScrollView();
    $scope.$broadcast('userDetailContent.scroll', scrollView);
  }

})

.controller('ChatsCtrl', function($scope, Chats, $ionicListDelegate) {
  // With the new view caching in Ionic, Controllers are only called
  // when they are recreated or on app start, instead of every page change.
  // To listen for when this page is active (for example, to refresh data),
  // listen for the $ionicView.enter event:
  //
  //$scope.$on('$ionicView.enter', function(e) {
  //});

  $scope.chats = Chats.all();
  $scope.remove = function(chat) {
    Chats.remove(chat);
  };

//1
  $scope.toggleStar = function(chat){
    chat.star = !chat.star;
    $ionicListDelegate.closeOptionButtons();
  }
  $scope.doRefresh = function(){
    $scope.chats = Chats.all();
    $scope.$broadcast('scroll.refreshComplete');
  }
})

.controller('ChatDetailCtrl', function($scope, $stateParams, Chats, $ionicScrollDelegate) { //Chats is the Factory Service we are using
  $scope.chat = Chats.get($stateParams.chatId);

//for parallax effect
  $scope.onUserDetailContentScroll = function(){
    var scrollDelegate = $ionicScrollDelegate.$getByHandle('userDetailContent');
    var scrollView = scrollDelegate.getScrollView();
    $scope.$broadcast('userDetailContent.scroll', scrollView);
  }

})

.controller('AccountCtrl', function($scope) {
  $scope.settings = {
    enableFriends: true
  };
});
